import streamlit as st
from os import file_selector

# st.download_button(data=Streamlit,label=' Breast Cancer Prediction')

if st.checkbox('Select a file to download'):
    st.write('~> Use if you want to test uploading / downloading a certain file.')

    # Upload file for testing
    folder_path = r'C:\Users\aredd\OneDrive\Desktop\PythonFiles\Streamlit'
    filename = file_selector(folder_path=folder_path)

    # Load selected file
    with open(filename, 'rb') as f:
        s = f.read()

    download_button_str = st.download_button(s, filename, f'Click here to download {filename}')